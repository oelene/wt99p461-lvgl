/*
 * SPDX-FileCopyrightText: 2023-2026 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: CC0-1.0
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/lock.h>
#include <sys/param.h>
#include "sdkconfig.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_timer.h"
#include "esp_lcd_panel_ops.h"
#include "esp_err.h"
#include "esp_log.h"
#include "lvgl.h"
#include "esp_cache.h"
#include "esp_private/esp_cache_private.h"
#include "esp_heap_caps.h"
#include "driver/ppa.h"
#include "linux/videodev2.h"
#include "wt_bsp.h"
#include "camera_uvc.h"

static const char *TAG = "factory_firmware";

#define CAMERA_DISPLAY_WIDTH 480U
#define CAMERA_NORMAL_HEIGHT 384U
#define CAMERA_FULLSCREEN_HEIGHT 640U
#define CAMERA_RGB888_BYTES_PER_PIXEL 3U
#define CAMERA_UI_BUFFER_SIZE \
    (CAMERA_DISPLAY_WIDTH * CAMERA_FULLSCREEN_HEIGHT * CAMERA_RGB888_BYTES_PER_PIXEL)

/* External UI functions from lvgl_demo_ui.c */
extern void lvgl_ui(lv_display_t *disp);
extern void update_camera_frame(uint8_t *buf, uint32_t width, uint32_t height);
extern void set_camera_error(const char *msg);
extern void update_led_color(uint8_t r, uint8_t g, uint8_t b);
extern bool camera_is_fullscreen(void);

/* Camera streaming state */
#if !WT_BSP_USB_DEVICE_UVC_ENABLED
static ppa_client_handle_t s_ppa_srm_handle = NULL;
#endif
static lv_display_t *s_lvgl_disp = NULL;
#if !WT_BSP_USB_DEVICE_UVC_ENABLED
static uint8_t *s_ui_cam_buffer[2] = {NULL, NULL};
static size_t s_ui_cam_buffer_size = 0;
static uint8_t s_current_buf_idx = 0;
#endif
static uint8_t s_led_red = 0;
static uint8_t s_led_green = 0;
static uint8_t s_led_blue = 0;
#if !WT_BSP_USB_DEVICE_UVC_ENABLED
static bool s_camera_buffer_error_logged = false;
#endif

#if !WT_BSP_USB_DEVICE_UVC_ENABLED
static bool alloc_camera_buffers(size_t buffer_size, uint8_t *buffers[2])
{
    size_t data_cache_line_size = 0;
    esp_err_t ret = esp_cache_get_alignment(MALLOC_CAP_SPIRAM, &data_cache_line_size);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to get cache alignment: %s", esp_err_to_name(ret));
        return false;
    }

    buffers[0] = heap_caps_aligned_alloc(data_cache_line_size, buffer_size, MALLOC_CAP_SPIRAM);
    buffers[1] = heap_caps_aligned_alloc(data_cache_line_size, buffer_size, MALLOC_CAP_SPIRAM);
    if (buffers[0] == NULL || buffers[1] == NULL) {
        free(buffers[0]);
        free(buffers[1]);
        buffers[0] = NULL;
        buffers[1] = NULL;
        if (!s_camera_buffer_error_logged) {
            ESP_LOGE(TAG, "Failed to allocate camera UI buffers: %u bytes each", (unsigned int)buffer_size);
            s_camera_buffer_error_logged = true;
        }
        return false;
    }

    s_camera_buffer_error_logged = false;
    return true;
}

/**
 * @brief Camera frame callback. Processes frame using PPA and updates UI.
 */
static void camera_frame_cb(uint8_t *buf, uint32_t width, uint32_t height, size_t len, void *user_data)
{
    if (s_ppa_srm_handle == NULL) {
        return;
    }

    ppa_srm_oper_config_t srm_config = {
        .in.buffer = buf,
        .in.pic_w = width,
        .in.pic_h = height,
        .in.srm_cm = PPA_SRM_COLOR_MODE_RGB565,
        .out.srm_cm = PPA_SRM_COLOR_MODE_RGB888,
        .scale_x = 1.0f,
        .scale_y = 1.0f,
        .rgb_swap = 0,
        .byte_swap = 0,
        .mode = PPA_TRANS_MODE_BLOCKING,
    };

    uint32_t out_w, out_h;
    size_t out_size;

    if (camera_is_fullscreen()) {
        /* Fullscreen: 640x480 block from input -> Rotate 90 -> 480x640 output */
        srm_config.in.block_w = 640;
        srm_config.in.block_h = 480;
        srm_config.in.block_offset_x = (width > 640) ? (width - 640) / 2 : 0;
        srm_config.in.block_offset_y = (height > 480) ? (height - 480) / 2 : 0;

        srm_config.out.pic_w = 480;
        srm_config.out.pic_h = 640;
        srm_config.rotation_angle = PPA_SRM_ROTATION_ANGLE_90;
        out_w = 480;
        out_h = 640;
    } else {
        /* Normal: 480x384 crop, no rotation */
        srm_config.in.block_w = 480;
        srm_config.in.block_h = 384;
        srm_config.in.block_offset_x = (width > 480) ? (width - 480) / 2 : 0;
        srm_config.in.block_offset_y = (height > 384) ? (height - 384) / 2 : 0;

        srm_config.out.pic_w = 480;
        srm_config.out.pic_h = 384;
        srm_config.rotation_angle = PPA_SRM_ROTATION_ANGLE_0;
        out_w = 480;
        out_h = 384;
    }

    out_size = out_w * out_h * CAMERA_RGB888_BYTES_PER_PIXEL;
    srm_config.out.buffer_size = out_size;

    uint8_t *new_buffers[2] = {NULL, NULL};
    uint8_t output_buf_idx = s_current_buf_idx;
    bool replacing_buffers = false;

    if (s_ui_cam_buffer[0] != NULL && s_ui_cam_buffer[1] != NULL && s_ui_cam_buffer_size >= out_size) {
        srm_config.out.buffer = s_ui_cam_buffer[output_buf_idx];
    } else {
        if (!alloc_camera_buffers(out_size, new_buffers)) {
            return;
        }
        srm_config.out.buffer = new_buffers[0];
        output_buf_idx = 0;
        replacing_buffers = true;
    }

    if (ppa_do_scale_rotate_mirror(s_ppa_srm_handle, &srm_config) == ESP_OK) {
        /* Invalidate CPU cache (RGB888 is 3 bytes/pixel) */
        esp_cache_msync((void *)srm_config.out.buffer,
                        out_size,
                        ESP_CACHE_MSYNC_FLAG_DIR_M2C);

        if (wt_bsp_dsi_lvgl_lock(pdMS_TO_TICKS(10))) {
            update_camera_frame(srm_config.out.buffer, out_w, out_h);
            lv_refr_now(s_lvgl_disp);
            wt_bsp_dsi_lvgl_unlock();
            if (replacing_buffers) {
                uint8_t *old_buffer_0 = s_ui_cam_buffer[0];
                uint8_t *old_buffer_1 = s_ui_cam_buffer[1];
                s_ui_cam_buffer[0] = new_buffers[0];
                s_ui_cam_buffer[1] = new_buffers[1];
                s_ui_cam_buffer_size = out_size;
                s_current_buf_idx = 1;
                free(old_buffer_0);
                free(old_buffer_1);
            } else {
                s_current_buf_idx = !output_buf_idx;
            }
        } else if (replacing_buffers) {
            free(new_buffers[0]);
            free(new_buffers[1]);
        }
    } else if (replacing_buffers) {
        free(new_buffers[0]);
        free(new_buffers[1]);
    }
}

#endif

/* Functions required by lvgl_demo_ui.c implemented using BSP */

void example_set_led_color(uint8_t r, uint8_t g, uint8_t b)
{
    s_led_red = r;
    s_led_green = g;
    s_led_blue = b;

    wt_bsp_rgb_t rgb = wt_bsp_get_rgb();
    if (rgb) {
        wt_bsp_rgb_set_pixel(rgb, 0, (wt_bsp_rgb_color_t){r, g, b});
        wt_bsp_rgb_refresh(rgb);
    }
}

esp_err_t example_sdcard_mount(void)
{
    wt_bsp_sdmmc_t sdmmc = wt_bsp_get_sdmmc();
    if (sdmmc == NULL) {
        return ESP_ERR_NOT_FOUND;
    }
    return wt_bsp_sdmmc_mount(sdmmc);
}

uint64_t example_sdcard_get_capacity(void)
{
    wt_bsp_sdmmc_t sdmmc = wt_bsp_get_sdmmc();
    if (sdmmc) {
        sdmmc_card_t *card = wt_bsp_sdmmc_get_card(sdmmc);
        if (card) {
            return ((uint64_t)card->csd.capacity) * card->csd.sector_size;
        }
    }
    return 0;
}

void app_main(void)
{
    ESP_LOGI(TAG, "Initializing Wireless-Tag BSP");
    esp_err_t ret = wt_bsp_init();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "BSP init failed: %s", esp_err_to_name(ret));
        return;
    }

#if WT_BSP_USB_DEVICE_UVC_ENABLED
    ret = camera_uvc_start();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Camera-to-UVC bridge failed: %s", esp_err_to_name(ret));
    }
#endif

    wt_bsp_dsi_t dsi = wt_bsp_get_dsi();
    wt_bsp_csi_t csi = wt_bsp_get_csi();
    wt_bsp_touch_t touch = wt_bsp_get_touch();
    wt_bsp_sdmmc_t sdmmc = wt_bsp_get_sdmmc();

    /* Hardware status detection */
    bool dsi_ok = (dsi != NULL);
    bool sdmmc_ok = false;
    if (sdmmc != NULL) {
        ret = wt_bsp_sdmmc_mount(sdmmc);
        if (ret == ESP_OK) {
            sdmmc_ok = true;
        } else {
            ESP_LOGW(TAG, "SDMMC mount failed: %s", esp_err_to_name(ret));
        }
    }
    bool csi_initialized = (csi != NULL);

    /* CSI status will be determined later when we actually try to start it */
    /* For LED indication, we assume CSI is OK if it initialized, will update if start fails */

    ESP_LOGI(TAG, "Hardware status: DSI=%d, CSI_init=%d, SDMMC=%d", dsi_ok, csi_initialized, sdmmc_ok);

    /* Set LED color based on initial hardware status (CSI will be verified later) */
    if (wt_bsp_get_rgb() != NULL) {
        if (!dsi_ok && !csi_initialized && !sdmmc_ok) {
            /* Screen, camera, and SD card all not connected: RED */
            ESP_LOGW(TAG, "No peripherals detected - LED RED");
            example_set_led_color(255, 0, 0);
        } else if (!csi_initialized && !sdmmc_ok) {
            /* Camera and SD card not connected (based on init): ORANGE */
            ESP_LOGW(TAG, "Camera and SD card not detected - LED ORANGE");
            example_set_led_color(255, 165, 0);
        } else if (!dsi_ok) {
            /* Screen not connected (with any other state): PINK */
            ESP_LOGW(TAG, "Screen not detected - LED PINK");
            example_set_led_color(255, 105, 180);
        } else if (!csi_initialized) {
            /* Only camera not connected (based on init): BLUE */
            ESP_LOGW(TAG, "Camera not detected (init failed) - LED BLUE");
            example_set_led_color(0, 0, 255);
        } else if (!sdmmc_ok) {
            /* Only SD card not connected: YELLOW */
            ESP_LOGW(TAG, "SD card not detected - LED YELLOW");
            example_set_led_color(255, 255, 0);
        } else {
            /* All hardware initialized: no LED indication */
            ESP_LOGI(TAG, "All peripherals initialized - LED OFF");
            example_set_led_color(0, 0, 0);
        }
    }

    /* Check if display is available before proceeding with UI */
    if (!dsi_ok) {
        ESP_LOGW(TAG, "Display not available, skipping UI initialization");
        ESP_LOGI(TAG, "Factory firmware example running (no display mode)");
        esp_err_t stop_ret = camera_uvc_stop();
        if (stop_ret == ESP_OK) {
            wt_bsp_deinit();
        } else {
            ESP_LOGE(TAG, "Bridge cleanup failed; retaining BSP resources: %s", esp_err_to_name(stop_ret));
        }
        while (1) {
            vTaskDelay(pdMS_TO_TICKS(100000));
        }
        return;
    }

    /* 1. Start LVGL */
    ESP_LOGI(TAG, "Starting LVGL");
    wt_bsp_dsi_lvgl_config_t lvgl_cfg = {
        .lvgl_port_cfg = ESP_LVGL_PORT_INIT_CONFIG(),
        .double_buffer = true,
        /* Allocate buffer for 1/10th of the screen */
        .buffer_size = 480 * 640,
        .flags = {
            .avoid_tearing = true,
        }
    };
    lvgl_cfg.lvgl_port_cfg.task_stack = 16384;
    //lvgl_cfg.lvgl_port_cfg.task_priority = 10;
    lv_display_t *disp = wt_bsp_dsi_lvgl_start(dsi, &lvgl_cfg);
    if (disp == NULL) {
        ESP_LOGE(TAG, "Failed to start LVGL display");
        return;
    }
    s_lvgl_disp = disp;

    /* 2. Setup Touch */
    if (touch) {
        wt_bsp_touch_lvgl_start(touch, disp);
    }

    /* 3. Setup UI */
    if (wt_bsp_dsi_lvgl_lock(portMAX_DELAY)) {
        lvgl_ui(disp);
        update_led_color(s_led_red, s_led_green, s_led_blue);
        wt_bsp_dsi_lvgl_unlock();
    }

    /* 4. Power on display backlight */
    wt_bsp_dsi_display_on(dsi);
    wt_bsp_dsi_set_brightness(dsi, 100);

#if !WT_BSP_USB_DEVICE_UVC_ENABLED
    /* This application assigns CSI either to the UVC bridge or the local UI. */
    if (csi) {
        ESP_LOGI(TAG, "Initializing PPA and Camera");
        ppa_client_handle_t ppa_srm_handle = NULL;
        ppa_client_config_t ppa_srm_config = {
            .oper_type = PPA_OPERATION_SRM,
        };
        ret = ppa_register_client(&ppa_srm_config, &ppa_srm_handle);
        if (ret == ESP_OK) {
            s_ppa_srm_handle = ppa_srm_handle;
        }

        if (ret == ESP_OK) {
            /* Configure camera to output RGB565 for the factory UI */
            ret = wt_bsp_csi_set_pixel_format(csi, V4L2_PIX_FMT_RGB565);
        }
        if (ret == ESP_OK) {
            ret = wt_bsp_csi_start(csi, camera_frame_cb, NULL);
        }
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "Failed to start camera: %s", esp_err_to_name(ret));
            free(s_ui_cam_buffer[0]);
            free(s_ui_cam_buffer[1]);
            s_ui_cam_buffer[0] = NULL;
            s_ui_cam_buffer[1] = NULL;
            if (s_ppa_srm_handle != NULL) {
                ppa_unregister_client(s_ppa_srm_handle);
                s_ppa_srm_handle = NULL;
            }
            if (wt_bsp_dsi_lvgl_lock(portMAX_DELAY)) {
                set_camera_error("Camera Init Failed");
                wt_bsp_dsi_lvgl_unlock();
            }
        }
    }

#endif

    ESP_LOGI(TAG, "Factory firmware example running");

    while (1) {
        vTaskDelay(pdMS_TO_TICKS(100000));
    }
}
