| Supported Targets | WT9932C2-TINY | WT9932C3-TINY | WT9932C5-TINY | WT9932C61-TINY | WT9932P4-TINY | WT9932P4C61-TINY | WT9932P4X-TINY | WT9932S31-TINY |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |

# Button Example

WT9932P4-TINY uses ESP32-P4 v1.x; WT9932P4X-TINY uses v3.x. They share peripheral wiring but require different firmware. Select the actual board with `idf.py set-board`; see the [revision and build notes](../../../components/wt_bsp/boards/WT9932P4X-TINY/README.md).

## Getting Started

1.  **Select the development board**: Run `idf.py set-board` in the example directory and select a supported development board. The command generates the board-level default configuration used by the next configure/build step:

```shell
~/WT_BSP/examples/get-started/button$ idf.py set-board
...
Supported boards in this example:
0: WT9932C2-TINY (esp32c2)
1: WT9932C3-TINY (esp32c3)
2: WT9932C5-TINY (esp32c5)
3: WT9932C61-TINY (esp32c61)
4: WT9932P4-TINY (esp32p4)
5: WT9932P4C61-TINY (esp32p4)
6: WT9932P4X-TINY (esp32p4)
7: WT9932S31-TINY (esp32s31)

Please select the target board by entering the corresponding number.
Enter board number:
```

Enter the number that matches your hardware kit model, then press Enter. A successful selection prints output similar to this:

```shell
Enter board number: 0
Generated sdkconfig.board
Generated sdkconfig.board.Kconfig
Updated build/sdkconfig
Selected WT9932C2-TINY (esp32c2)
```

Then run `idf.py build` to compile:

```shell
~/WT_BSP/examples/get-started/button$ idf.py build
Executing action: all (aliases: build)
Running ninja in directory ~/WT_BSP/examples/get-started/button/build
Executing "ninja all"...
...
```

After modifying the code, run `idf.py build` again to compile.

> During development, you can switch to another hardware kit whenever needed. When switching to a different target chip, `idf.py fullclean` is automatically executed.

## Example Output

After building and flashing the firmware, each BOOT button operation prints the corresponding state log. Example runtime logs:

```shell
I (1489) main_task: Calling app_main()
I (1489) button: Initializing Wireless-Tag BSP
I (1499) button: IoT Button Version: 4.2.0
W (1499) button: Please operate the button
I (6009) button: Button click
I (7009) button: Button press
I (7509) button: Button press
I (8009) button: Button click
I (9009) button: Button press
I (10009) button: Button long press
I (10509) button: Button long press
I (11009) button: Button long press
I (11509) button: Button long press
I (12009) button: Button long press
I (12509) button: Button long press
I (13009) button: Button release
```

## WT9932S31-TINY

With ESP-IDF v6.1 or later, run from the repository root:

```shell
WT_BSP_BOARD=WT9932S31-TINY idf.py --preview -C examples/get-started/button build
```
