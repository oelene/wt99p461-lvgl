import argparse
import os
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


ANSI_GREEN = "\033[32m"
ANSI_RESET = "\033[0m"

# Chip revision variants reuse the base board's peripheral implementation.
BOARD_VARIANTS = {
    "WT9932P4X-TINY": "WT9932P4-TINY",
}


class BspBoardError(Exception):
    pass


@dataclass
class Board:
    name: str
    target: str
    file_id: str
    config: str
    defaults: Optional[Path] = None


def normalize_board_name(name):
    normalized = re.sub(r"[^0-9A-Za-z]+", "_", name.strip()).strip("_")
    return normalized.lower()


def find_repo_root(start):
    current = Path(start).resolve()
    if current.is_file():
        current = current.parent

    for path in (current, *current.parents):
        if (path / "components" / "wt_bsp" / "boards").is_dir():
            return path

    raise BspBoardError("Unable to find WT_BSP repository root from {}".format(current))


def discover_boards(repo_root):
    boards_dir = Path(repo_root) / "components" / "wt_bsp" / "boards"
    if not boards_dir.is_dir():
        raise BspBoardError("Board directory not found: {}".format(boards_dir))

    boards = {}
    for kconfig_path in sorted(boards_dir.glob("*/Kconfig.projbuild")):
        text = kconfig_path.read_text(encoding="utf-8")
        config_match = re.search(r"^\s*config\s+(WT_BSP_BOARD_[A-Z0-9_]+)\s*$", text, re.MULTILINE)
        target_match = re.search(r"^\s*depends\s+on\s+IDF_TARGET_([A-Z0-9_]+)\s*$", text, re.MULTILINE)
        if not config_match or not target_match:
            continue

        name = kconfig_path.parent.name
        boards[name] = Board(
            name=name,
            target=target_match.group(1).lower(),
            file_id=normalize_board_name(name),
            config="CONFIG_{}".format(config_match.group(1)),
        )

    if not boards:
        raise BspBoardError("No WT_BSP boards found in {}".format(boards_dir))

    for name, base_name in BOARD_VARIANTS.items():
        base = boards.get(base_name)
        if base is not None:
            boards[name] = Board(
                name=name,
                target=base.target,
                file_id=normalize_board_name(name),
                config=base.config,
            )

    return dict(sorted(boards.items()))


def find_board(boards, board_name):
    board_key = board_name.strip().lower()
    board_file_id = normalize_board_name(board_name)

    for board in boards.values():
        if board_key == board.name.lower() or board_file_id == board.file_id:
            return board

    raise BspBoardError(
        "Unknown board '{}'. Available boards: {}".format(
            board_name,
            ", ".join(sorted(boards)),
        )
    )


def project_board_defaults(project_path, board):
    project = Path(project_path)
    return project / "sdkconfig.{}".format(board.file_id)


def available_project_boards(project_path, boards):
    project = Path(project_path)
    return {
        name: board
        for name, board in boards.items()
        if project_board_defaults(project, board).is_file()
    }


def with_project_defaults(project_path, board):
    return Board(
        name=board.name,
        target=board.target,
        file_id=board.file_id,
        config=board.config,
        defaults=project_board_defaults(project_path, board),
    )


def _is_generated_config_line(line):
    stripped = line.strip()
    return (
        stripped.startswith("CONFIG_WT_BSP_BOARD_")
        or stripped.startswith("# CONFIG_WT_BSP_BOARD_")
        or stripped.startswith("CONFIG_WT_BSP_SELECTED_BOARD_")
        or stripped.startswith("# CONFIG_WT_BSP_SELECTED_BOARD_")
        or _is_target_config_line(line)
    )


def _is_target_config_line(line):
    stripped = line.strip()
    return (
        stripped.startswith("CONFIG_IDF_TARGET=")
        or stripped.startswith("CONFIG_IDF_TARGET_")
        or stripped.startswith("# CONFIG_IDF_TARGET_")
    )


def _is_board_hardware_config_line(line, target):
    stripped = line.strip()
    return (
        stripped.startswith("CONFIG_ESP32P4_SELECTS_REV_LESS_V3")
        or stripped.startswith("# CONFIG_ESP32P4_SELECTS_REV_LESS_V3")
        or stripped.startswith("CONFIG_ESP32P4_REV_MIN_")
        or stripped.startswith("# CONFIG_ESP32P4_REV_MIN_")
        # 400 MHz remains a valid Kconfig choice on v1.x, so stale v3.x
        # settings would override the legacy board's 360 MHz defaults.
        or (target == "esp32p4" and (
            stripped.startswith("CONFIG_ESP_DEFAULT_CPU_FREQ_MHZ")
            or stripped.startswith("# CONFIG_ESP_DEFAULT_CPU_FREQ_MHZ")
        ))
    )


def _filtered_defaults_lines(lines):
    return [line.rstrip("\n") for line in lines if not _is_generated_config_line(line)]


def _filtered_active_sdkconfig_lines(lines, target):
    return [
        line.rstrip("\n")
        for line in lines
        if not _is_generated_config_line(line) and not _is_board_hardware_config_line(line, target)
    ]


def _target_from_text(text):
    target_match = re.search(r'^CONFIG_IDF_TARGET="([^"]+)"$', text, re.MULTILINE)
    if target_match:
        return target_match.group(1)

    return None


def _cmake_cache_target(build_dir):
    if not build_dir:
        return None

    cache = Path(build_dir) / "CMakeCache.txt"
    if not cache.is_file():
        return None

    text = cache.read_text(encoding="utf-8", errors="replace")
    target_match = re.search(r"^IDF_TARGET:[^=]*=(.+)$", text, re.MULTILINE)
    if target_match:
        return target_match.group(1).strip()

    return None


def _display_path(path, base):
    try:
        return path.relative_to(base)
    except ValueError:
        return path


def board_selector_config(board):
    return board.config.replace("CONFIG_WT_BSP_BOARD_", "WT_BSP_SELECTED_BOARD_", 1)


def generate_sdkconfig_board_kconfig(project_path, board):
    project = Path(project_path)
    output = project / "sdkconfig.board.Kconfig"
    text = "\n".join(
        [
            "# This file is generated by `idf.py set-board`. Do not edit.",
            "",
            "config WT_BSP_BOARD_SELECTED_BY_TOOL  # ignore: multiple-definition",
            "    bool",
            "    default y",
            "",
            "config {}  # ignore: multiple-definition".format(board_selector_config(board)),
            "    bool",
            "    default y",
            "",
        ]
    )
    output.write_text(text, encoding="utf-8")
    return output


def generate_sdkconfig_board(project_path, board):
    project = Path(project_path)
    if board.defaults is None:
        board = with_project_defaults(project, board)

    if not board.defaults.is_file():
        raise BspBoardError(
            "Board defaults file not found: {}. Create sdkconfig.{} in this example.".format(
                board.defaults,
                board.file_id,
            )
        )

    lines = _filtered_defaults_lines(board.defaults.read_text(encoding="utf-8").splitlines())
    while lines and not lines[-1].strip():
        lines.pop()

    generated = [
        "# This file is generated by `idf.py set-board`. Do not edit.",
        "# Source: {}".format(board.defaults.name),
        "",
    ]
    generated.extend(lines)
    if lines:
        generated.append("")
    generated.extend(
        [
            "{}=y".format(board.config),
            'CONFIG_IDF_TARGET="{}"'.format(board.target),
            "CONFIG_IDF_TARGET_{}=y".format(board.target.upper()),
            "",
        ]
    )

    output = project / "sdkconfig.board"
    output.write_text("\n".join(generated), encoding="utf-8")
    return output


def read_sdkconfig_board_target(project_path):
    project = Path(project_path)
    sdkconfig_board = project / "sdkconfig.board"
    if not sdkconfig_board.is_file():
        raise BspBoardError("Generated board defaults not found: {}".format(sdkconfig_board))

    text = sdkconfig_board.read_text(encoding="utf-8")
    target = _target_from_text(text)
    if not target:
        raise BspBoardError("Unable to find CONFIG_IDF_TARGET in {}".format(sdkconfig_board))

    return target


def sync_project_sdkconfig_target(project_path, target, sdkconfig_path=None, create=False, board=None):
    project = Path(project_path)
    sdkconfig = Path(sdkconfig_path) if sdkconfig_path else project / "sdkconfig"
    if not sdkconfig.is_file():
        if not create:
            return None
        sdkconfig.parent.mkdir(parents=True, exist_ok=True)
        text = ""
        current_target = None
    else:
        text = sdkconfig.read_text(encoding="utf-8")
        current_target = _target_from_text(text)

    if current_target and current_target != target:
        sdkconfig.with_name("sdkconfig.old").write_text(text, encoding="utf-8")
        lines = []
    elif board is not None:
        lines = _filtered_active_sdkconfig_lines(text.splitlines(), target)
    else:
        # A normal reconfigure must retain the native choice saved by menuconfig.
        # Only an explicit set-board operation replaces a previous board choice.
        lines = [line for line in text.splitlines() if not _is_target_config_line(line)]

    while lines and not lines[-1].strip():
        lines.pop()

    if lines:
        lines.append("")
    if board is not None:
        lines.append("{}=y".format(board.config))
        if board.defaults is not None:
            lines.extend(
                line for line in board.defaults.read_text(encoding="utf-8").splitlines()
                if _is_board_hardware_config_line(line, target)
            )
    lines.extend(
        [
            'CONFIG_IDF_TARGET="{}"'.format(target),
            "CONFIG_IDF_TARGET_{}=y".format(target.upper()),
            "",
        ]
    )

    sdkconfig.write_text("\n".join(lines), encoding="utf-8")
    return sdkconfig


def prepare_board(project_path, board_name):
    repo_root = find_repo_root(project_path)
    boards = discover_boards(repo_root)
    board = with_project_defaults(project_path, find_board(boards, board_name))
    sdkconfig_output = generate_sdkconfig_board(project_path, board)
    kconfig_output = generate_sdkconfig_board_kconfig(project_path, board)
    return board, sdkconfig_output, kconfig_output


def format_available_boards(project_path, boards):
    available = available_project_boards(project_path, boards)
    if not available:
        return "No sdkconfig.<board> files found in this example."

    return "\n".join(
        "{} ({})".format(board.name, board.target)
        for board in available.values()
    )


def _available_boards_or_error(project_path):
    repo_root = find_repo_root(project_path)
    boards = discover_boards(repo_root)
    available = available_project_boards(project_path, boards)
    if not available:
        raise BspBoardError("No sdkconfig.<board> files found in this example.")

    return available


def _read_input(prompt, input_fn):
    if input_fn is input:
        sys.stdout.write(prompt)
        sys.stdout.flush()
        return input_fn()

    return input_fn(prompt)


def select_board(project_path, board_name=None, input_fn=input, output_fn=print):
    available = _available_boards_or_error(project_path)

    if board_name:
        return with_project_defaults(project_path, find_board(available, board_name))

    boards = list(available.values())
    output_fn("{}Supported boards in this example:".format(ANSI_GREEN))
    for index, board in enumerate(boards):
        output_fn("{}: {} ({})".format(index, board.name, board.target))
    output_fn("")
    output_fn("Please select the target board by entering the corresponding number.{}".format(ANSI_RESET))

    while True:
        output_fn("{}Enter board number: {}".format(ANSI_GREEN, ANSI_RESET))
        value = _read_input("", input_fn).strip()
        if value.lower() in ("x", "q", "quit", "exit"):
            raise BspBoardError("Board selection cancelled")

        if value.isdigit():
            index = int(value)
            if 0 <= index < len(boards):
                return with_project_defaults(project_path, boards[index])

        try:
            return with_project_defaults(project_path, find_board(available, value))
        except BspBoardError:
            output_fn("Invalid board selection {}".format(value))


def _run_set_target(project_path, target, build_dir=None, run_command=None):
    idf_path = os.environ.get("IDF_PATH")
    command = [sys.executable, str(Path(idf_path) / "tools" / "idf.py")] if idf_path else ["idf.py"]
    if target == "esp32s31":
        command.append("--preview")
    command.extend(["-C", str(project_path)])
    if build_dir:
        command.extend(["-B", str(build_dir)])

    command.extend(["set-target", target])
    if run_command is None:
        run_command = subprocess.run
    run_command(command, check=True, cwd=str(project_path))


def _run_fullclean(project_path, build_dir=None, run_command=None):
    idf_path = os.environ.get("IDF_PATH")
    command = [sys.executable, str(Path(idf_path) / "tools" / "idf.py")] if idf_path else ["idf.py"]
    command.extend(["-C", str(project_path)])
    if build_dir:
        command.extend(["-B", str(build_dir)])

    command.append("fullclean")
    if run_command is None:
        run_command = subprocess.run
    run_command(command, check=True, cwd=str(project_path))


def run_set_board(
        project_path,
        build_dir=None,
        board_name=None,
        sdkconfig_path=None,
        input_fn=input,
        output_fn=print,
        run_command=None,
        set_target=True,
        fullclean_on_target_change=False):
    project = Path(project_path).resolve()
    selected = select_board(project, board_name=board_name, input_fn=input_fn, output_fn=output_fn)
    cached_target = _cmake_cache_target(build_dir)
    sdkconfig_output = generate_sdkconfig_board(project, selected)
    kconfig_output = generate_sdkconfig_board_kconfig(project, selected)
    target_changed = cached_target is not None and cached_target != selected.target

    if target_changed and fullclean_on_target_change:
        output_fn(
            "Target changed from {} to {}; running idf.py fullclean".format(
                cached_target,
                selected.target,
            )
        )
        sys.stdout.flush()
        _run_fullclean(project, build_dir=build_dir, run_command=run_command)

    sdkconfig = sync_project_sdkconfig_target(
        project, selected.target, sdkconfig_path=sdkconfig_path, create=True, board=selected,
    )

    output_fn("Generated {}".format(_display_path(sdkconfig_output, project)))
    output_fn("Generated {}".format(_display_path(kconfig_output, project)))
    if sdkconfig is not None:
        output_fn("Updated {}".format(_display_path(sdkconfig, project)))
    output_fn("Selected {} ({})".format(selected.name, selected.target))
    if set_target:
        _run_set_target(project, selected.target, build_dir=build_dir, run_command=run_command)
    return selected, sdkconfig_output, kconfig_output


def main(argv=None):
    parser = argparse.ArgumentParser(description="Select a WT_BSP board for the current ESP-IDF project.")
    parser.add_argument("-p", "--project-path", required=True, help="ESP-IDF project directory.")
    parser.add_argument("-B", "--build-dir", help="ESP-IDF build directory.")
    parser.add_argument("--sdkconfig", help="Active sdkconfig path to sync with the selected board target.")
    parser.add_argument("-b", "--board", help="Board name. Defaults to WT_BSP_BOARD or interactive selection.")
    parser.add_argument("--list", action="store_true", help="List boards supported by this project and exit.")
    parser.add_argument("--generate-only", action="store_true", help="Only generate sdkconfig.board files.")
    parser.add_argument(
        "--fullclean-on-target-change",
        action="store_true",
        help="Run idf.py fullclean when the selected board target differs from the current CMake cache target.",
    )
    parser.add_argument("--quiet", action="store_true", help="Suppress informational output.")
    parser.add_argument("--sync-target-from-board", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args(argv)

    project = Path(args.project_path).resolve()
    try:
        if args.list:
            boards = discover_boards(find_repo_root(project))
            print(format_available_boards(project, boards))
            return 0

        if args.sync_target_from_board:
            sync_project_sdkconfig_target(
                project,
                read_sdkconfig_board_target(project),
                sdkconfig_path=args.sdkconfig,
                create=bool(args.sdkconfig),
            )
            return 0

        board_name = args.board or os.environ.get("WT_BSP_BOARD")
        output_fn = (lambda message: None) if args.quiet else print
        run_set_board(
            project,
            build_dir=args.build_dir,
            board_name=board_name,
            sdkconfig_path=args.sdkconfig,
            output_fn=output_fn,
            set_target=not args.generate_only,
            fullclean_on_target_change=args.fullclean_on_target_change,
        )
    except subprocess.CalledProcessError as error:
        print("set-target failed with exit code {}".format(error.returncode))
        return error.returncode
    except BspBoardError as error:
        print(error)
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
