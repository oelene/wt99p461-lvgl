# AGENTS.md

本文件给在本仓库工作的 AI 编码代理使用。开始修改前先阅读本文件，并以现有代码和 README 为准。

## 项目概览

这是 Wireless-Tag 的 ESP-IDF Board Support Package 仓库。核心组件位于 `components/wt_bsp`，用于给多块 Wireless-Tag TINY 系列 ESP32 开发板提供统一的 `wt_bsp_*` API。示例工程位于 `examples`。

项目仅支持 ESP-IDF `v6.0.0` 及以上版本，组件声明为 `idf >=6.0.0`。
WT9932S31-TINY 需要 ESP-IDF `v6.1` 及以上版本；v6.1 中的选板、配置和构建命令需加 `--preview`。

## 目录职责

- `components/wt_bsp/include/`：BSP 顶层聚合头文件，例如 `wt_bsp.h` 和 `wt_bsp_port.h`。
- `components/wt_bsp/src/`：BSP 核心通用实现，例如 `wt_bsp.c`。
- `components/wt_bsp/features/<FEATURE>/`：公共外设能力实现；每个功能自带 `CMakeLists.txt`、`include/wt_bsp_<feature>.h`、`include/wt_bsp_<feature>_port.h` 和实现文件。
- `components/wt_bsp/boards/<BOARD>/`：单板适配，包括引脚、资源数量、板卡初始化、对象生命周期、Kconfig 和 CMake 接入。
- `components/wt_bsp/tools/`：BSP 构建辅助工具，例如 `wt_bsp_set_board.py` 和 `wt_bsp_project.cmake`。
- `components/wt_bsp/wt_bsp_config_internal.h`：把板卡能力和 menuconfig 裁剪选择合成为 BSP 内部有效功能宏。
- `components/wt_bsp/idf_component.yml`：ESP-IDF 组件依赖声明。
- `examples/get-started/blink/`：基础 RGB 示例。
- `examples/display/dsi/`：ESP32-P4 DSI/LVGL 示例。
- `examples/camera/csi/`：ESP32-P4 CSI 摄像头示例。
- `examples/storage/sdmmc/`：ESP32-P4 SDMMC 示例。
- `examples/wt_factory/*/`：综合工厂测试固件。

## 构建和验证

先确保已经加载 ESP-IDF 环境，例如：

```bash
. /path/to/esp-idf/export.sh
```

常用验证命令：

交互使用保留 `idf.py set-board` 再 `idf.py build` 的流程。下面的显式环境变量形式由项目 CMake 辅助工具支持，不依赖 `idf_ext.py`。

```bash
WT_BSP_BOARD=WT9932C2-TINY idf.py -C examples/get-started/blink -B build-wt9932c2-tiny build
WT_BSP_BOARD=WT9932C3-TINY idf.py -C examples/get-started/blink -B build-wt9932c3-tiny build
WT_BSP_BOARD=WT9932C5-TINY idf.py -C examples/get-started/blink -B build-wt9932c5-tiny build
WT_BSP_BOARD=WT9932C61-TINY idf.py -C examples/get-started/blink -B build-wt9932c61-tiny build
WT_BSP_BOARD=WT9932P4-TINY idf.py -C examples/display/dsi -B build-wt9932p4-tiny build
WT_BSP_BOARD=WT9932P4-TINY idf.py -C examples/camera/csi -B build-wt9932p4-tiny build
WT_BSP_BOARD=WT9932P4-TINY idf.py -C examples/storage/sdmmc -B build-wt9932p4-tiny build
WT_BSP_BOARD=WT9932P4-TINY idf.py -C examples/wt_factory/wt9932p4-tiny -B build-wt9932p4-tiny build
WT_BSP_BOARD=WT9932P4C61-TINY idf.py -C examples/wt_factory/wt9932p4c61-tiny -B build-wt9932p4c61-tiny build
```

提交前至少运行：

```bash
git diff --check
```

如果改动只影响某一类外设，优先构建覆盖该外设的示例；如果改动公共接口、Kconfig、CMake 或 `wt_bsp_config_internal.h`，至少覆盖一个非 P4 目标和一个 P4 目标。

不要提交 `build/`、`examples/**/build*`、`examples/**/sdkconfig`、`managed_components/`、`dependencies.lock`、IDE 配置和系统临时文件。

### 较大改动提交前的本地 CI 确认

- 较大改动包括公共 API、公共实现、CMake/Kconfig、依赖版本、CI 构建逻辑，以及影响多个示例或板卡的修改。
- 这类改动准备执行 `git commit` 时，先询问用户："本次改动影响多个构建组合，是否先在 /tmp 副本中运行全量本地 CI，全部通过后再提交？" 收到答复后再执行相应流程；本轮已明确同意运行或跳过时，沿用该决定，不重复询问。
- 用户选择运行时，使用下面的方法覆盖完整矩阵，全部成功后再提交。任一组合失败时先修复；每次修改构建相关代码或配置后，重新创建快照并从头验证所有组合。
- 用户选择跳过时，仍执行相关基础检查，并在提交结果中明确说明未运行全量本地 CI。纯文档修改不按较大改动处理。

### 在 /tmp 副本中运行 CI 构建脚本

直接运行 `.github/scripts/build_examples.py`，复用 `.github/workflows/examples.yml` 的矩阵和构建入口，无需启动 GitHub、Docker 或 act。此方法验证构建脚本，不等同于验证 GitHub 事件触发或云端 SDK 安装。

先在同一终端执行一次 `get_idf`；若无此命令，使用实际 SDK 路径的 `export.sh`。SDK 版本应与工作流一致，当前为 ESP-IDF v6.1。这里的“离线本地触发”指不依赖 GitHub 服务；完全断网构建需要事先准备好 SDK、工具链及组件依赖缓存，首次依赖解析或下载仍可能需要联网。

从仓库根目录运行以下命令。快照包含工作区中已跟踪文件的当前内容和未被 Git 忽略的新文件，因此可验证尚未 commit 的修改；被忽略的构建产物不会复制。每个组合使用独立副本，避免选板配置、依赖锁文件和旧构建目录相互影响。

```bash
python - <<'PY'
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

root = Path(subprocess.check_output(["git", "rev-parse", "--show-toplevel"], text=True).strip())
idf = Path(os.environ["IDF_PATH"]) / "tools/idf.py"
subprocess.run([sys.executable, str(idf), "--version"], check=True)
run_dir = Path(tempfile.mkdtemp(prefix="wt-bsp-ci-", dir="/tmp"))
snapshot = run_dir / "source"
snapshot.mkdir()
names = subprocess.check_output(
    ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"], cwd=root
).decode().split("\0")
for name in sorted(set(names) - {""}):
    source = root / name
    if source.is_file():
        target = snapshot / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)

script = Path(".github/scripts/build_examples.py")
matrix = json.loads(subprocess.check_output(
    [sys.executable, "-B", str(snapshot / script), "--matrix"], text=True
))["include"]
(run_dir / "matrix.json").write_text(json.dumps(matrix, indent=2) + "\n")
print(f"CI directory: {run_dir}; combinations: {len(matrix)}", flush=True)
failed = []
for index, case in enumerate(matrix, 1):
    work = run_dir / f"case-{index:02d}"
    shutil.copytree(snapshot, work)
    label = f"{case['example']} / {case['board'] or case['target']}"
    log = run_dir / f"case-{index:02d}.log"
    print(f"[{index}/{len(matrix)}] {label}; log: {log}", flush=True)
    with log.open("w") as output:
        result = subprocess.run(
            [sys.executable, "-B", str(work / script), "--example", case["example"],
             "--board", case["board"], "--target", case["target"]],
            cwd=work, stdout=output, stderr=subprocess.STDOUT,
        )
    if result.returncode:
        failed.append(label)
    print("FAIL" if result.returncode else "PASS", flush=True)
print(f"Passed: {len(matrix) - len(failed)}/{len(matrix)}; failed: {failed}")
raise SystemExit(1 if failed else 0)
PY
```

以脚本生成的完整矩阵为准，不硬编码组合数量。所有组合退出码均为 0 才算通过；单个失败后继续记录其余组合。报告通过数、失败组合和 `/tmp` 日志目录，并确认待提交源码仍与验证快照一致。

## 架构约束

- 应用层只能通过 `#include "wt_bsp.h"` 使用 BSP，不直接 include `boards/<BOARD>/board.h` 或 `board_config.h`。
- 板级引脚、硬件资源数量、屏幕/摄像头型号等硬件差异只放在 `components/wt_bsp/boards/<BOARD>/`。
- 可被多块板复用的外设能力应沉淀到 `features/<FEATURE>/`，不要复制到多个板级目录。
- CSI、JPEG camera 和 USB UVC 独立启用；摄像头到 UVC 的桥接、USB profile 和消费者仲裁放在应用层。
- camera 板级只提供统一 `wt_bsp_camera_info_t`、sensor 名称、属性及静态对象；interface 自动路由到自注册 factory，公共调用经统一 `wt_bsp_camera_ops_t` 分发。新增 sensor 的 `.c/.h` 不应要求修改公共 camera 源文件或板级引用驱动符号。
- `wt_bsp_init()` 获取当前 Kconfig 选中的 `board_get_bsp_interface()` 并调用板级 `init()`；板级 `init()` 只初始化当前工程有效启用的 feature。
- `wt_bsp_get_*()` 可能返回 `NULL`。示例和应用必须处理功能未启用、初始化失败或硬件缺失的情况。
- `wt_bsp_interface_t` 字段保持固定，不按功能宏裁剪；不支持的功能由板级接口表显式填 `NULL`。
- `board_init()` 初始化中途失败时要释放已经初始化的资源；`board_deinit()` 按初始化的反向顺序释放。
- 对外对象优先由板级静态对象持有，避免让应用管理 BSP 资源生命周期。
- SoC 差异优先用 ESP-IDF 配置或能力宏隔离，例如 `IDF_TARGET_*`、`CONFIG_SOC_*`，不要把专用实现强行编入所有目标。

## 新增板卡流程

1. 新建 `components/wt_bsp/boards/<BOARD>/`。
2. 添加 `board.c`、`board.h`、`board_config.h`、`CMakeLists.txt`、`Kconfig.projbuild`。
3. 在本板 `Kconfig.projbuild` 中定义隐藏的 `WT_BSP_SELECTED_BOARD_*`，向命名 `choice WT_BSP_BOARD` 贡献成员、目标依赖和选板工具默认值。同一目标仅默认板提供目标回退默认值。公共 Kconfig/CMake 通过通配符收集目录，无需修改公共文件；额外板级菜单放入可选 `Kconfig.options`，并依赖本板选择。
4. 在板级 `CMakeLists.txt` 中仅当对应 `CONFIG_WT_BSP_BOARD_*` 启用时追加源文件、include 目录和 `WT_BSP_BOARD_FEATURES` 能力名。
5. 在 `board_config.h` 中声明该板硬件具备的能力，命名使用 `WT_BSP_BOARD_HAS_<FEATURE>`，例如 RGB、button、SDMMC、DSI、CSI、touch。
6. 在板级 `Kconfig.projbuild` 中为该板 `select WT_BSP_BOARD_HAS_<FEATURE>`，让 menuconfig 只能在板卡能力边界内裁剪。
7. 在 `board.c` 中实现板卡信息、资源初始化/释放、`get_*` 函数和 `board_get_bsp_interface()`。
8. BSP 板卡接入只需新增本板目录；若还需让已有示例的 `set-board` 菜单提供该板，在该示例新增 `sdkconfig.<board_id>`，例如 `sdkconfig.wt9932p4_tiny`。示例预设用于限定已适配的组合。
9. 编译至少一个该板对应的示例，并确认 `idf.py set-board`、`WT_BSP_BOARD=<BOARD> idf.py set-board` 或 `WT_BSP_BOARD=<BOARD> idf.py build` 会生成正确的 `sdkconfig.board`、`sdkconfig.board.Kconfig` 和目标芯片配置；跨目标芯片切板时应自动触发 `fullclean`。

## 新增公共外设能力

1. 新建 `components/wt_bsp/features/<FEATURE>/`。
2. 添加 `CMakeLists.txt`、`include/wt_bsp_<feature>.h`、`include/wt_bsp_<feature>_port.h` 和 `wt_bsp_<feature>.c`。
3. 在 feature 的 `CMakeLists.txt` 中始终追加自身 include 目录，并仅当能力名存在于 `WT_BSP_BOARD_FEATURES` 且 `CONFIG_WT_BSP_ENABLE_<FEATURE>` 启用时追加 `WT_BSP_FEATURE_SRCS`、`WT_BSP_FEATURE_REQUIRES` 和 `WT_BSP_FEATURE_PRIV_REQUIRES`；不要调用 `idf_component_register()`。
4. 添加 `Kconfig.projbuild`，定义隐藏的 `WT_BSP_BOARD_HAS_<FEATURE>` 和用户可见的 `CONFIG_WT_BSP_ENABLE_<FEATURE>`；后者必须 `depends on WT_BSP_BOARD_HAS_<FEATURE>` 并默认 `y`，共享 USB 控制器等需要应用显式启动的功能可默认 `n`。如需用该开关控制托管依赖，增加始终导出的隐藏字符串 `WT_BSP_DEP_<FEATURE>`，按有效开关取 `"y"`/`"n"`；清单用 `matches` 判断它。沿用现有双引号比较值和括号分组，并用真实 Kconfig JSON/Component Manager 解析器验证，避免不可见 bool 缺失或条件误解析。
5. 在 `include/wt_bsp.h` 中包含公共头，在 `include/wt_bsp_port.h` 中包含 port 头。
6. 如需新的默认资源获取函数，在固定结构的 `wt_bsp_interface_t` 中添加对应 `get_<feature>` 指针，并在不支持的板级接口表中显式填 `NULL`。
7. 在 `src/wt_bsp.c` 中添加 `wt_bsp_get_<feature>()`，并保持未初始化或不可用时返回 `NULL`。
8. 在 `wt_bsp_config_internal.h` 中加入或扩展对应 `WT_BSP_<FEATURE>_ENABLED`，其语义必须是 `WT_BSP_BOARD_HAS_<FEATURE> && CONFIG_WT_BSP_ENABLE_<FEATURE>`。
9. 在需要支持该能力的 `board_config.h` 和 `board.c` 中接入资源；`board.c` 中的对象、初始化、反初始化和 getter 必须按 `WT_BSP_<FEATURE>_ENABLED` 条件编译。
10. 同步更新 README、示例或测试路径。

## 代码风格

- 主要代码为 C，沿用现有 ESP-IDF 风格和文件结构注释。
- 公共头文件的新增 API 要写清 Doxygen 注释，说明参数、返回值和生命周期。
- 返回 `esp_err_t` 的公共函数要保持错误语义稳定；获取类函数失败时返回 `NULL`，字符串获取失败时沿用现有空字符串或默认值约定。
- 日志使用 `ESP_LOG*`，tag 使用当前模块名。
- 回调中只做轻量操作，耗时逻辑交给任务处理。
- LVGL API 调用需要遵循示例中的 lock/unlock 约定。
- 除非同一文件已有明确不同风格，否则新代码使用 ASCII 标点和空格。

## C/H 规范整理

以下规范以当前 `components/wt_bsp` 中的 `.c`、`.h` 文件为基准。新增代码优先遵守本节；整理旧代码时只做与当前改动相关的局部修正，不为无关文件做大范围格式化。

### 文件结构

- `.c` 和 `.h` 文件保留现有文件头注释格式，至少包含 `@file`、`@author`、`@brief`、`@version`、`@date` 和版权信息。
- 文件内分区使用现有横幅注释，顺序保持一致：
  1. `Includes`
  2. `Defines`
  3. `Typedefs`
  4. `Static Prototypes`（仅 `.c` 需要）
  5. `Static Variables`（仅 `.c` 需要）
  6. `Macros`
  7. `Global Functions` 或 `Global Prototypes`
  8. `Static Functions`（仅 `.c` 需要）
- 空分区可以保留，便于不同文件保持结构统一。
- `#include` 顺序：本模块头文件优先，例如 `.c` 先 include 对应 `.h` 或 `board.h`；再 include BSP 内部头；最后 include ESP-IDF、驱动、标准库头。不同类别之间可用一个空行分隔。
- 公共头文件使用 include guard，命名沿用 `__WT_BSP_XXX_H__`、`__BOARD_CONFIG_H__` 这类全大写形式。
- 公共 C++ 兼容包装使用：
  ```c
  #ifdef __cplusplus
  extern "C" {
  #endif

  ...

  #ifdef __cplusplus
  } /* extern "C" */
  #endif
  ```

### 命名约定

- 公共 API 使用 `wt_bsp_<feature>_<action>()`，获取默认对象使用 `wt_bsp_get_<feature>()`。
- 公共类型使用 `wt_bsp_<feature>_xxx_t`；对象句柄使用指向不透明结构的 typedef，例如 `typedef struct wt_bsp_rgb_obj_t *wt_bsp_rgb_t;`。
- 对象实体结构使用 `wt_bsp_<feature>_obj_t`；配置结构使用 `wt_bsp_<feature>_info_t`。
- 板级私有函数使用 `board_<action>()`；板级静态对象使用 `s_bsp_<feature>`；文件内全局状态使用 `s_` 前缀。
- 文件内日志 tag 使用 `static const char *TAG = "模块名";`，例如 `"wt_bsp_rgb"` 或 `"board"`。
- 宏使用全大写。板级硬件参数使用 `BOARD_<FEATURE>_<NAME>`；板卡硬件边界使用 `WT_BSP_BOARD_HAS_<FEATURE>`；应用裁剪使用 `CONFIG_WT_BSP_ENABLE_<FEATURE>`；BSP 内部有效开关使用 `WT_BSP_<FEATURE>_ENABLED`。
- 内部哨兵枚举值可使用 `_WT_BSP_<FEATURE>_...` 前缀，避免被应用层当作普通枚举使用。

### 格式与排版

- 缩进使用 4 个空格，不使用 tab。
- 函数左花括号单独一行；`if`、`for`、`while`、`switch` 的左花括号与语句同行。
- 关键字后保留一个空格，例如 `if (ret != ESP_OK)`；函数调用名与左括号之间不加空格。
- 指针星号靠近变量名或参数名，沿用当前写法，例如 `const wt_bsp_rgb_info_t *info`、`static const char *TAG`。
- 结构体、数组和对象初始化优先使用 designated initializer，并在多字段初始化时每个字段单独一行，末尾保留逗号。
- 复合字面量初始化沿用当前 ESP-IDF 风格，例如：
  ```c
  ret = wt_bsp_rgb_init(&s_bsp_rgb, &(wt_bsp_rgb_info_t) {
      .gpio_num = BOARD_RGB_GPIO_NUM,
      .model = BOARD_RGB_MODEL,
  });
  ```
- 多行函数调用参数按现有代码对齐到参数列，尤其是底层驱动 API 调用。
- `switch` 的 `case` 与 `switch` 同级缩进，`case` 内语句缩进一级。
- 不新增行尾空格；提交前运行 `git diff --check`。

### 头文件与 Doxygen

- 公共头文件中的类型、枚举、结构体字段和函数都要写 Doxygen 注释。
- 函数注释至少包含 `@brief`、必要的 `@param[in]`/`@param[out]`/`@param[in,out]` 和所有稳定返回语义。
- 对象生命周期必须写清楚：由谁初始化、谁反初始化、返回的句柄是否可被应用释放。
- 获取类 API 的注释要明确不可用时返回 `NULL`；字符串获取类 API 要明确失败时是否返回空字符串。
- `board_config.h` 中的板卡能力宏使用单行 Doxygen 注释，说明该板是否具备某能力或数量含义。
- 应用层和示例只 include `wt_bsp.h`；公共头文件不要暴露 `boards/<BOARD>/board.h` 或板级私有配置。

### 错误处理与资源生命周期

- 返回 `esp_err_t` 的函数先检查参数，参数无效返回 `ESP_ERR_INVALID_ARG` 并记录 `ESP_LOGE`。
- 初始化函数使用 `esp_err_t ret = ESP_OK;` 承接每一步结果；失败时释放已经成功初始化的资源，再返回原始错误码。
- `board_init()` 可重复调用；已经初始化时记录 warning 并返回 `ESP_OK`。
- `board_deinit()` 按初始化的反向顺序释放资源。无依赖关系的资源尽力清理；任务或驱动停止失败且仍借用资源时，保留该对象及其依赖和 BSP 所有权，返回错误供应用重试。全部释放成功后才清除初始化状态。
- 清理函数应允许部分初始化状态，释放前检查句柄是否为 `NULL`，成功释放后将句柄清为 `NULL`；失败时保留重试所需状态。应用须先成功停止消费者和 camera-to-UVC 桥接，再释放 BSP，不能从帧回调重入生命周期 API。
- `wt_bsp_get_*()`、`board_get_*()` 不转移对象所有权；返回板级静态对象地址或 `NULL`。
- 外设缺失、功能未启用或初始化失败时，示例和应用必须处理 `NULL` 句柄，不假设硬件一定存在。

### 条件编译与 SoC 差异

- 条件编译统一通过 `wt_bsp_config_internal.h` 中的 `WT_BSP_<FEATURE>_ENABLED` 使用；不要直接用 `WT_BSP_BOARD_HAS_<FEATURE>` 代替有效开关。
- menuconfig 裁剪项命名为 `CONFIG_WT_BSP_ENABLE_<FEATURE>`，必须依赖对应 `WT_BSP_BOARD_HAS_<FEATURE>`，避免应用打开板卡不支持的功能。
- 功能宏可以裁剪 feature 源文件、依赖、port 对象定义和外设专用 API，但不要裁剪 `wt_bsp_interface_t` 字段。
- 公共头文件中仅在能力启用时暴露特定外设类型和 API；公共入口 `wt_bsp.h` 可以提供稳定的获取函数声明。
- feature 目录只通过自己的 `CMakeLists.txt` 追加源码、include 目录和依赖；顶层组件只统一收集变量并调用一次 `idf_component_register()`。
- 板级 `CMakeLists.txt` 负责声明当前板支持的 feature 能力列表，feature `CMakeLists.txt` 不硬编码具体板名。
- SoC 后端差异优先使用 ESP-IDF 能力宏，例如 `SOC_RMT_SUPPORTED`、`SOC_GPSPI_SUPPORTED`，不要用板名硬编码公共实现。
- 板级目录只编译当前 Kconfig 选中的板卡文件；不要让某块板的私有实现进入所有目标。

### 注释和日志

- 注释用于解释硬件约束、资源顺序、非显然行为和失败后继续执行的原因；不要为直观赋值写重复注释。
- 新增注释优先使用中文或英文中的一种，并与所在文件现有注释保持一致。
- 日志消息使用英文，沿用当前风格；错误日志包含失败步骤和 `esp_err_to_name(ret)`。
- 非致命失败使用 `ESP_LOGW`，成功路径的重要硬件状态可用 `ESP_LOGI`，高频路径避免刷日志。

### 示例代码

- 示例入口先调用 `wt_bsp_init()` 并检查返回值；失败时打印错误并退出当前示例逻辑。
- 示例获取外设后必须判断句柄是否为 `NULL`，再调用对应 API。
- LVGL 示例中所有 LVGL 对象操作遵守已有 lock/unlock 约定。
- 示例中不要 include 板级私有头，不要复制板级引脚定义；硬件差异应由 BSP 层封装。

## 修改注意事项

- 不要引入与当前 BSP 目标无关的应用业务逻辑。
- 不要把示例里的临时配置、生成文件或本地构建产物提交。
- 不要为了单个板卡的特殊需求污染公共 API；先判断是否可以留在板级目录。
- 修改 CMake/Kconfig 时要考虑所有支持目标，尤其是 ESP32-P4 与 C2/C3/C5/C61 的差异。
- README 中可能存在历史路径或示例名，执行命令前以当前仓库实际目录为准。
